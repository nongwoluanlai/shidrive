---
name: shidrive-dynamic-skin
description: 把用户提供的角色素材图（透明底立绘 + 同构图表情图 + 可选背景）做成 ShiDrive 可导入的动态皮肤 zip（分层 WebGL 看板：头发/衣摆飘动、呼吸、眨眼、视线跟随、事件换表情，可选全局特效）。适用场景：用户要"做一个 XX 的动态皮肤"、发来皮肤素材图，或者要调整已有动态皮肤的细节。
---

# ShiDrive 动态皮肤制作

## 前提

- ShiDrive 客户端需要包含动态皮肤引擎（`app/src/lib/skin-fx/`、`skins.rs` 中的 `validate_scene`）。
- 引擎**只是渲染器**：皮肤内容（表情、事件映射、特效预设、配色）**全部写在皮肤包的 `skin.json` 里**，绝不写进客户端代码。
- 静态内置皮肤与旧版静态 zip 包保持原样，动态版作为**新的独立皮肤 id** 存在（例如 `kurisu-dynamic`）。
- 格式细节见 `references/schema.md`（或仓库 `docs/skin-guide.md` 的"动态皮肤"一节）。

## 协作流程（固定四步）

1. **给提示词**：把 `templates/prompts.md` 发给用户。用户只需改【角色描述】，然后自己去生图。
2. **收素材 → 出包**：用户发来素材（常见是 zip，扩展名可能被加了 `.txt`，按 zip 解压；文件名可能是 GBK/cp437 编码，要转码）。按下文"构建步骤"产出 `<id>.zip`，再附上预览（sheet.png / preview.mp4）。
3. **用户导入核验**：在 设置 → 皮肤插件 → 导入皮肤包（zip）里导入。
4. **按反馈调整**：见"常见调整"表，改 config 后重新 build，**id 不变**。提醒用户：导入同 id 的皮肤包前，要先在皮肤列表里删除旧版本。

## 构建步骤

依赖：`pip install pillow numpy scipy`；预览额外需要 `playwright imageio imageio-ffmpeg`，并执行 `python -m playwright install --with-deps chromium`。

```bash
mkdir -p work/<id> && cd work/<id>          # 放入 body.png face_*.png bg.png
cp <skill>/templates/skin.config.example.json skin.config.json   # 改 id/name/description/配色/特效
python <skill>/scripts/build_skin.py inspect skin.config.json    # ① 素材检查 + 自动定位脸部
#   → 用 read_file 查看 work/inspect.png：绿椭圆要框住整张脸（眉毛到下巴），红点在脖子，蓝点在胸口
#   → 定位不准时，把 anchors.face_ellipse / neck / chest / head 手动写进 config
python <skill>/scripts/build_skin.py build skin.config.json      # ② 产出 package/<id>/ 与 package/<id>.zip
#   → 查看 work/mask_preview.png：红=头发（发根不动、发梢动），绿=衣摆，蓝=呼吸
python <skill>/scripts/preview/record.py package/<id> preview       # ③ 真实渲染器冒烟测试 + 视频
<skill>/scripts/verify/verify_import.sh <shidrive仓库> package/<id>.zip <id>   # ④ 用客户端的 Rust 导入代码校验
```

`scripts/preview/engine.js` 是把客户端真实的 `scene.ts` + `global-fx.ts` + `bus.ts` 打包出来的（入口 `scripts/preview/entry.ts`，里面的路径指向仓库，按需修改）。引擎更新后要重新生成：
`npx esbuild@0.24 <skill>/scripts/preview/entry.ts --bundle --format=esm --outfile=<skill>/scripts/preview/engine.js`

record.py 的时间线：待机 → 点击人物 → 失败 → 发送 → 回复中 → 完成。输出 preview.mp4、sheet.png（6 格截图）、heads.png（头部特写）。swiftshader 是软件渲染，全屏特效叠加时截图可能卡几秒（日志里的 slow screenshot），这不代表真机性能。

### 自检清单（交付前必须逐条确认）

- [ ] `inspect` 没有报 ✗；所有表情图和立绘尺寸一致
- [ ] 表情层接缝检查：把每个 patch 按 `rect` 贴回立绘，放大头部查看，不能有接缝、错位或双重线条（本文末尾附有脚本）
- [ ] `mask_preview.png`：脸、手、腿、鞋没有被染红或染绿；领带、发带轻微飘动可以接受
- [ ] `record.py` 输出 `renderer fails: [] console errors: []`
- [ ] `verify_import.sh` 输出 `OK`
- [ ] 包体 < 32 MiB，单文件 < 8 MiB，skin.json < 64 KiB（build 会自动检查）

## 关键设计决定（不要改）

| 决定 | 原因 |
|---|---|
| 表情用**同构图全身图**生成，工具只截取羽化椭圆内的脸部 | AI 重绘会让全图线条轻微抖动；只取脸部，身体始终是同一张图，不会闪烁 |
| 自动定位脸部用**强差异阈值（>150）**找眼睛带，再推算椭圆 | 弱阈值会把全图线条抖动也算进去，导致定位跑偏（实际踩过这个坑） |
| 相位相关对齐，偏移 >40px 的不对齐 | 修正 1–3px 的生成偏移；偏移太大说明图有问题，应该让用户重新生成 |
| `runtime_scale` 0.6（1024×1536 → 614×922） | 看板约 340×600 CSS 像素 × DPR 1.5；再大只会浪费显存，还会发糊（不生成 mipmap） |
| `size` 保持原图坐标，贴图按比例缩小 | rect、pivot 都用原图像素写，便于手工微调 |
| 背景转成 JPEG q88，最长边 ≤2560 | 5 MB 的 PNG 背景会压到 1 MB 以内 |
| `character` 字段指向 body.png | 旧客户端或动效关闭时，仍能显示静态立绘 |
| 特效预设写在皮肤包里 | 引擎不内置任何预设（例如世界线） |

## 常见调整（用户反馈 → 改哪里）

| 反馈 | 修改 |
|---|---|
| 头发飘得太大/太小 | `idle.hairAmp`（默认 32，范围 0–90）；阵风 `idle.gust`（0–1）；发梢滞后 `idle.lag`（0–3）；整体风力 `idle.wind`（0–2） |
| 衣摆太大/太小 | `idle.coatAmp`（默认 20，范围 0–60） |
| 领带、手等被识别成头发 | `hair.exclude: [[x0,y0,x1,y1]]`（原图坐标） |
| 说话一直张嘴 | `clips.talk.keys.talk` 用 `{"flap":[90,170],"burst":[900,2400],"rest":[500,1400]}` |
| 点人物没反应/太频繁 | `on["character.click"]` 与片段的 `cooldown`（毫秒） |
| 时间轴装饰 | `timeline: {art, mark, height, railColor}`，支持 SVG（不能包含脚本或外链） |
| 某处不该动（手、腿、领带） | `coat.exclude: [[x0,y0,x1,y1]]`；或者画 `work/mask_hair.png` / `mask_coat.png`（白=动），会覆盖自动遮罩 |
| 头发识别漏了或多了 | `hair.h_range`（色相，支持跨 0°，如 `[340, 28]` 表示红棕）、`s_min`、`v_min`、`reach` |
| 眨眼太频繁 | `idle.blink.every: [3, 8]`（秒），双眨概率 `idle.blink.double` |
| 表情持续太短/太长 | `clips.<name>.dur` 和关键帧 `[[ms, 0..1]]` |
| 换事件映射 | `on: {"message.send": "smug", ...}`；可用事件：message.send / agent.streaming / agent.done / agent.error / character.click / skin.enter；值也可以是数组，表示随机挑一个 |
| 表情有接缝或双重线条 | 加大 `patch_pad`（默认 1.35）或调大 `anchors.face_ellipse` 的半径；仍然不行就让用户用立绘作参考重新生成该表情 |
| 表情在看板里看不清 | 看板小时脸只有约 30px，属于正常现象；可以建议用户生成更"夸张"的表情（加大眼睛和嘴的变化） |
| 特效太吵 | 删除或弱化 `globalFx.on` 的绑定；用户也可以在 设置 → 皮肤动效 里切到"轻量" |

## 接缝检查脚本

```python
import json; from PIL import Image
d = "package/<id>"; m = json.load(open(f"{d}/skin.json")); s = m["scene"]; W, H = s["body"]["size"]
b = Image.open(f"{d}/body.png").convert("RGBA").resize((W, H))
fx, fy, rx, ry = <face_ellipse>; box = (fx-rx*1.4, fy-ry*1.3, fx+rx*1.4, fy+ry*1.5)
out = Image.new("RGB", (len(s["layers"]) * 200 + 200, 220))
for i, l in enumerate([None] + s["layers"]):
    im = b.copy()
    if l: x, y, w, h = l["rect"]; im.alpha_composite(Image.open(f"{d}/{l['src']}").convert("RGBA").resize((w, h)), (x, y))
    out.paste(im.crop(tuple(map(int, box))).convert("RGB").resize((200, 220)), (i * 200, 0))
out.save("preview/patches.png")
```

## 已知坑

- 同一回合里并行执行 bash 和 read_file 会读到旧文件：生成图片后，要在下一步再读取。
- 无头 Chromium 需要 `--use-angle=swiftshader`；只用 `--use-gl=swiftshader` 可能会丢失 WebGL 上下文，导致画面空白。
- swiftshader 下 `generateMipmap` 会让纹理变成透明：引擎只用 LINEAR 过滤，不要改。
- 用 file:// 打开预览会触发跨域纹理错误：record.py 会自己起 HTTP 服务。
- 目录名不要叫 `out`、`dist`、`build`（沙箱快照会排除这些目录），所以工具默认输出到 `package/`。
