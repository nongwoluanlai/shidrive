#!/usr/bin/env python3
"""
ShiDrive 动态皮肤构建工具：把素材图做成可导入的皮肤 zip

  python build_skin.py inspect  skin.config.json   # 素材检查 + 自动定位脸部 → work/inspect.png
  python build_skin.py build    skin.config.json   # 产出 package/<id>/ 目录、<id>.zip，以及 mask/patch 预览图

素材约定（都放在 config 所在目录，或者用绝对路径）：
  body.png            透明底立绘（必需）
  face_<name>.png     表情图。和立绘同尺寸（mode=full，推荐：用立绘当参考图编辑得到），
                      或者只有脸部（mode=crop，需要在 config 的 expressions 里写 rect）
  bg.png / bg.jpg     应用背景（可选）

依赖：pip install pillow numpy scipy
"""
import json, os, sys, zipfile, shutil
import numpy as np
from PIL import Image, ImageFilter

EVENTS = {"message.send", "agent.streaming", "agent.done", "agent.error", "skin.enter", "character.click"}
MAX_ASSET, MAX_TOTAL = 8 << 20, 32 << 20


# ----------------------------------------------------------------------------- utils
def load_cfg(path):
    cfg = json.load(open(path, encoding="utf-8"))
    cfg["_base"] = os.path.dirname(os.path.abspath(path))
    cfg.setdefault("work_dir", "work"); cfg.setdefault("dist_dir", "package")
    cfg.setdefault("runtime_scale", 0.6)
    cfg.setdefault("expressions", {})
    return cfg

def P(cfg, p): return p if os.path.isabs(p) else os.path.join(cfg["_base"], p)

def rgba(path):
    return np.asarray(Image.open(path).convert("RGBA"), float)

def blur(m, r):
    return np.asarray(Image.fromarray((np.clip(m, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r)), float) / 255

def save(arr, path, mode="RGBA"):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), mode).save(path)

def phase_shift(a, b):
    """相位相关：估计 b 相对 a 的整体平移（像素），用于纠正 AI 编辑后的轻微错位。"""
    F = np.fft.fft2(a) * np.conj(np.fft.fft2(b))
    r = np.fft.ifft2(F / (np.abs(F) + 1e-6)).real
    dy, dx = np.unravel_index(np.argmax(r), r.shape)
    h, w = a.shape
    if dy > h // 2: dy -= h
    if dx > w // 2: dx -= w
    return int(dx), int(dy)

def hsv(rgb):
    h = np.asarray(Image.fromarray(rgb.astype(np.uint8)).convert("HSV"), float)
    return h[..., 0] * 360 / 255, h[..., 1], h[..., 2]


# ----------------------------------------------------------------------------- inspect
def auto_face(body, exprs):
    """找脸：表情图与立绘的"强差异"（>150）集中在眼睛和嘴，AI 重绘造成的线条抖动差异较弱。
    取差异最强的峰值（通常是一只眼睛），合并其附近（半径约 W*0.16）的差异块（另一只眼、嘴），
    用这些五官的外接框推算整张脸的椭圆。"""
    from scipy import ndimage as nd
    H, W = body.shape[:2]
    top = int(H * 0.5)                                 # 脸只可能在上半身
    acc = np.zeros((top, W))
    for v in exprs.values():
        acc += (np.abs(v[:top, :, :3] - body[:top, :, :3]).sum(-1) * (body[:top, :, 3] > 128)) > 150
    h = nd.gaussian_filter(acc, W / 128)
    py, px = np.unravel_index(h.argmax(), h.shape)
    lab, n = nd.label(h > h.max() * 0.3)
    xs0, ys0, xs1, ys1 = [], [], [], []
    for i in range(1, n + 1):
        ys, xs = np.nonzero(lab == i)
        if h[lab == i].sum() < h.max() * 50: continue                  # 零星噪点
        if np.hypot(xs.mean() - px, ys.mean() - py) > W * 0.16: continue  # 离五官太远（手、头发）
        xs0.append(xs.min()); xs1.append(xs.max()); ys0.append(ys.min()); ys1.append(ys.max())
    x0, x1, y0, y1 = min(xs0), max(xs1), min(ys0), max(ys1)
    rx = int(np.clip((x1 - x0) * 0.55, W * 0.04, W * 0.16))
    ry = int(max(rx * 1.1, (y1 - y0) * 0.75))
    return [int((x0 + x1) / 2), int((y0 + y1) / 2 + ry * 0.08), rx, ry]

def inspect(cfg):
    work = P(cfg, cfg["work_dir"]); os.makedirs(work, exist_ok=True)
    body = rgba(P(cfg, cfg.get("body", "body.png")))
    H, W = body.shape[:2]
    ok = True
    print(f"body: {W}x{H}, 透明像素 {((body[..., 3] < 10).mean() * 100):.1f}%")
    if (body[..., 3] < 10).mean() < 0.2:
        print("  ✗ 立绘几乎没有透明区域：请提供真透明底 PNG（不要白底或棋盘格）"); ok = False
    exprs = {}
    for name, spec in cfg["expressions"].items():
        f = P(cfg, spec if isinstance(spec, str) else spec["src"])
        if not os.path.exists(f): print(f"  ✗ 缺少 {f}"); ok = False; continue
        v = rgba(f)
        if isinstance(spec, str) and v.shape[:2] != (H, W):
            print(f"  ✗ {name}: 尺寸 {v.shape[1]}x{v.shape[0]} 与立绘不同 → 重新生成，或者改用 crop 模式并写 rect"); ok = False; continue
        exprs[name] = v
        print(f"  ✓ {name}")
    if exprs and "face_ellipse" not in cfg.get("anchors", {}):
        fe = auto_face(body, {k: v for k, v in exprs.items() if isinstance(cfg["expressions"][k], str)})
        print(f"自动定位 face_ellipse = {fe}  （写进 config.anchors.face_ellipse 后可手动微调）")
        cfg.setdefault("anchors", {})["face_ellipse"] = fe
    fx, fy, rx, ry = cfg["anchors"]["face_ellipse"]
    a = cfg["anchors"]
    a.setdefault("neck", [fx, int(fy + ry * 1.25)])
    a.setdefault("chest", [fx, int(fy + ry * 3.2)])
    a.setdefault("head", [fx, int(fy - ry * 0.3)])
    print(f"anchors: {json.dumps(a)}")
    # 预览：头部特写 + 锚点标注
    from PIL import ImageDraw
    im = Image.new("RGBA", (W, H), (40, 44, 52, 255)); im.alpha_composite(Image.fromarray(body.astype(np.uint8)))
    d = ImageDraw.Draw(im)
    d.ellipse([fx - rx, fy - ry, fx + rx, fy + ry], outline=(0, 255, 120), width=3)
    for k, c in (("neck", (255, 80, 80)), ("chest", (80, 160, 255)), ("head", (255, 220, 0))):
        x, y = a[k]; d.ellipse([x - 8, y - 8, x + 8, y + 8], fill=c); d.text((x + 12, y - 6), k, fill=c)
    im.convert("RGB").resize((W // 2, H // 2)).save(os.path.join(work, "inspect.png"))
    print("→", os.path.join(work, "inspect.png"), "（绿框应当框住整张脸，包括眉毛和下巴）")
    return ok


# ----------------------------------------------------------------------------- masks
def build_masks(cfg, rgb, a):
    """RGBA 形变遮罩：R=头发风力 G=衣摆风力 B=呼吸 A=头部跟随。"""
    H, W = a.shape
    A = cfg["anchors"]; hx, hy = A["head"]; fx, fy, frx, fry = A["face_ellipse"]
    yy, xx = np.mgrid[0:H, 0:W]
    hue, sat, val = hsv(rgb)
    hc = cfg.get("hair", {"s_max": 45, "v_min": 120})
    if "h_range" in hc:
        h0, h1 = hc["h_range"]
        inh = (hue >= h0) & (hue <= h1) if h0 <= h1 else (hue >= h0) | (hue <= h1)   # 支持跨 0° 的红色
        hair = inh & (sat > hc.get("s_min", 60)) & (val > hc.get("v_min", 40))
    else:
        hair = (sat < hc["s_max"]) & (val > hc["v_min"])
    hair = hair.astype(float) * (a > .5)
    for x0_, y0_, x1_, y1_ in hc.get("exclude", []): hair[y0_:y1_, x0_:x1_] = 0   # 领带、红色饰品等同色但不该飘的区域
    reach = hc.get("reach", H * 0.3)
    dist = np.hypot(xx - hx, (yy - hy) * .9)
    hairw = hair * np.clip((dist - fry) / max(1, reach - fry), 0, 1) ** 1.3        # 发根固定，发梢自由
    face = np.exp(-(((xx - fx) / frx) ** 2 + ((yy - fy) / fry) ** 2))
    hairw *= 1 - np.clip(face * 1.5, 0, 1)                                       # 脸上的刘海不动

    c = cfg.get("coat", {})
    y0, y1 = int(c.get("y_start", H * .45)), int(c.get("y_end", H * .8))
    cm = (a > .5) & (hair < .5)
    if "s_max" in c: cm &= sat < c["s_max"]
    if "v_min" in c: cm &= val > c["v_min"]
    if "h_range" in c: cm &= (hue >= c["h_range"][0]) & (hue <= c["h_range"][1]) & (sat > c.get("s_min", 40))
    excl = np.zeros_like(a)
    for x0_, y0_, x1_, y1_ in c.get("exclude", []): excl[y0_:y1_, x0_:x1_] = 1
    # 离身体中线越远，飘动越大（衣摆外缘动得多，贴身的部分动得少）
    side = np.clip(np.abs(xx - A["chest"][0]) / (W * c.get("side_falloff", .18)), 0.25, 1) if c.get("side_weight", True) else 1
    coat = cm.astype(float) * np.clip((yy - y0) / max(1, (y1 - y0) * .9), 0, 1) * np.clip((y1 + 80 - yy) / 160, 0, 1) * (1 - excl) * side

    cx, cy = A["chest"]
    breath = np.exp(-(((xx - cx) / (W * .2)) ** 2 + ((yy - cy) / (H * .09)) ** 2)) * (a > .3)
    nx, ny = A["neck"]
    headm = np.clip(1 - (yy - ny) / (fry * 1.6), 0, 1) * np.exp(-((xx - nx) / (W * .43)) ** 2)

    R, G, B, AA = blur(hairw, W / 70), blur(coat, W / 55), blur(breath, 10), blur(headm, 20)
    R /= max(R.max(), 1e-3); G /= max(G.max(), 1e-3)
    for ch, name in ((0, "hair"), (1, "coat"), (2, "breath"), (3, "head")):         # 人工修正优先
        f = P(cfg, os.path.join(cfg["work_dir"], f"mask_{name}.png"))
        if os.path.exists(f):
            print(f"  使用人工遮罩 {f}")
            [R, G, B, AA][ch][:] = np.asarray(Image.open(f).convert("L").resize((W, H)), float) / 255
    return np.dstack([R, G, B, AA])


# ----------------------------------------------------------------------------- face patches
def build_patches(cfg, body, out):
    H, W = body.shape[:2]
    fx, fy, rx, ry = cfg["anchors"]["face_ellipse"]
    pad = cfg.get("patch_pad", 1.35)
    x0, x1 = max(0, int(fx - rx * pad)), min(W, int(fx + rx * pad))
    y0, y1 = max(0, int(fy - ry * pad)), min(H, int(fy + ry * pad))
    base = body[y0:y1, x0:x1]
    gy, gx = np.mgrid[y0:y1, x0:x1]
    # 羽化椭圆：椭圆内完整替换，边缘 15% 过渡，避免 AI 重绘带来的线条抖动露出接缝
    e = np.sqrt(((gx - fx) / (rx * 1.12)) ** 2 + ((gy - fy) / (ry * 1.12)) ** 2)
    feather = np.clip((1.0 - e) / 0.15, 0, 1)
    rs = cfg["runtime_scale"]; layers = []
    for name, spec in cfg["expressions"].items():
        src = P(cfg, spec if isinstance(spec, str) else spec["src"])
        v = rgba(src)
        if not isinstance(spec, str):                          # crop 模式：贴回 rect 位置
            rx0, ry0, rw, rh = spec["rect"]
            full = body.copy(); full[ry0:ry0 + rh, rx0:rx0 + rw] = np.asarray(Image.fromarray(v.astype(np.uint8)).resize((rw, rh), Image.LANCZOS), float)
            v = full
        crop = v[y0:y1, x0:x1]
        dx, dy = phase_shift(base[..., :3].mean(-1), crop[..., :3].mean(-1))
        if max(abs(dx), abs(dy)) >= 2 and abs(dx) < 40 and abs(dy) < 40:   # ≤1px 视为噪声，不移动
            print(f"  [{name}] 检测到偏移 dx={dx} dy={dy}，已对齐")
            crop = np.asarray(Image.fromarray(v.astype(np.uint8)).transform((W, H), Image.AFFINE, (1, 0, -dx, 0, 1, -dy)), float)[y0:y1, x0:x1]
        change = (np.abs(crop[..., :3] - base[..., :3]).sum(-1) > 60) & (feather > .5)
        if change.sum() < 40:
            print(f"  [{name}] ✗ 脸部几乎没有变化，已跳过（检查表情图是否真的改了表情）"); continue
        alpha = feather * np.minimum(crop[..., 3], base[..., 3]) / 255
        ys, xs = np.nonzero(alpha > .02)
        bx0, bx1, by0, by1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        patch = np.dstack([crop[..., :3], alpha * 255])[by0:by1, bx0:bx1]
        img = Image.fromarray(patch.astype(np.uint8))
        img = img.resize((max(1, round(img.width * rs)), max(1, round(img.height * rs))), Image.LANCZOS)
        img.save(os.path.join(out, f"face_{name}.png"), optimize=True)
        rect = [int(x0 + bx0), int(y0 + by0), int(bx1 - bx0), int(by1 - by0)]
        layers.append({"id": name, "src": f"face_{name}.png", "rect": rect,
                       "bind": cfg.get("binds", {}).get(name, name)})
        print(f"  [{name}] rect={rect}  变化像素 {int(change.sum())}")
    return layers


# ----------------------------------------------------------------------------- build
# 默认表演（可在 config 里整体覆盖 clips / on / idle）：
#   回复中 = 说话（说一阵、停一阵，不会一直张嘴）   回复完成 = 得意   出错 = 惊讶
#   点击人物 = 害羞惊讶（有冷却）   发送消息 = 点头   空闲时偶尔闭目或浅笑
DEFAULT_CLIPS = {
    "ack":      {"dur": 700, "keys": {"nod": [[0, 0], [160, 1], [520, 0]]}},
    "talk":     {"dur": 2400, "keys": {"talk": {"flap": [90, 170], "burst": [900, 2400], "rest": [500, 1400]}}, "maxDur": 30000},
    "smug":     {"dur": 2200, "keys": {"smug": [[0, 0], [160, 1], [1800, 1], [2200, 0]], "nod": [[0, 0], [200, 1], [560, 0]]}},
    "surprise": {"dur": 1800, "keys": {"surprise": [[0, 0], [80, 1], [1500, 1], [1800, 0]], "jolt": [[0, 0], [60, 1], [380, 0]], "blinkHold": [[0, 1], [1800, 1]]}},
    "poke":     {"dur": 1500, "cooldown": 2500, "keys": {"surprise": [[0, 0], [60, 1], [1200, 1], [1500, 0]], "jolt": [[0, 0], [50, 1], [300, 0]], "blinkHold": [[0, 1], [1500, 1]]}},
    "rest":     {"dur": 1600, "keys": {"closed": [[0, 0], [200, 1], [1300, 1], [1600, 0]]}},
    "smirk":    {"dur": 1400, "keys": {"smug": [[0, 0], [200, 1], [1000, 1], [1400, 0]]}},
}
DEFAULT_ON = {"message.send": "ack", "agent.streaming": "talk", "agent.done": "smug", "agent.error": "surprise", "character.click": "poke"}
DEFAULT_IDLE = {"wind": 1, "breath": 1, "hairAmp": 32, "coatAmp": 20, "gust": 0.6, "lag": 1.2, "windDir": 0.3,
                "blink": {"every": [2, 6], "double": .15}, "gaze": {"maxRot": .04},
                "actions": {"every": [35, 80], "clips": ["rest", "smirk"]}}
SIMPLE_SVG_BANNED = ("<script", "javascript:", "foreignobject", "<!entity", "<!doctype", "@import", "<iframe", "<use")

def build(cfg):
    if not inspect(cfg): sys.exit("素材检查未通过")
    sid = cfg["id"]
    out = os.path.join(P(cfg, cfg["dist_dir"]), sid)
    shutil.rmtree(out, ignore_errors=True); os.makedirs(out)
    body = rgba(P(cfg, cfg.get("body", "body.png"))); H, W = body.shape[:2]
    rgb, a = body[..., :3], body[..., 3] / 255
    rs = cfg["runtime_scale"]
    Image.fromarray(body.astype(np.uint8)).resize((round(W * rs), round(H * rs)), Image.LANCZOS).save(os.path.join(out, "body.png"), optimize=True)
    m = build_masks(cfg, rgb, a)
    Image.fromarray((m * 255).astype(np.uint8), "RGBA").resize((W // 4, H // 4), Image.BILINEAR).save(os.path.join(out, "mask.png"), optimize=True)
    work = P(cfg, cfg["work_dir"]); os.makedirs(work, exist_ok=True)
    bg = Image.new("RGB", (W, H), (25, 25, 35)); bg.paste(Image.fromarray(body.astype(np.uint8)), (0, 0), Image.fromarray(body.astype(np.uint8)))
    Image.blend(bg, Image.fromarray((m[..., :3] * 255).astype(np.uint8)), .55).resize((W // 3, H // 3)).save(os.path.join(work, "mask_preview.png"))
    print("遮罩预览 →", os.path.join(work, "mask_preview.png"), "（红=头发 绿=衣摆 蓝=呼吸）")
    layers = build_patches(cfg, body, out)
    names = {l["id"] for l in layers}
    binds = cfg.get("binds", {})
    clips = {}
    for k, v in cfg.get("clips", DEFAULT_CLIPS).items():
        v = json.loads(json.dumps(v))
        v["keys"] = {binds.get(p, p): kv for p, kv in v["keys"].items()}      # 表情名 → 绑定参数（closed → blink）
        if all(p in ("nod", "jolt", "blinkHold", "blink") or p in {l["bind"] for l in layers} for p in v["keys"]):
            clips[k] = v
        else:
            print(f"  跳过片段 {k}：引用了不存在的表情层")
    def pick(v):
        lst = [c for c in (v if isinstance(v, list) else [v]) if c in clips]
        return lst if len(lst) > 1 else (lst[0] if lst else None)
    on = {e: pick(c) for e, c in cfg.get("on", DEFAULT_ON).items() if e in EVENTS and pick(c)}
    idle = json.loads(json.dumps(cfg.get("idle", DEFAULT_IDLE)))
    if idle.get("actions"):
        idle["actions"]["clips"] = [c for c in idle["actions"]["clips"] if c in clips]
    scene = {
        "body": {"src": "body.png", "size": [W, H], "grid": cfg.get("grid", [40, 72])},
        "mask": "mask.png",
        "pivot": {"neck": cfg["anchors"]["neck"], "chest": cfg["anchors"]["chest"]},
        "layers": layers,
        "idle": idle,
        "clips": clips, "on": on,
    }
    manifest = {"id": sid, "name": cfg.get("name", sid)}
    if cfg.get("description"): manifest["description"] = cfg["description"]
    if cfg.get("background"):
        bgi = Image.open(P(cfg, cfg["background"])).convert("RGB")
        bgi.thumbnail((cfg.get("background_max", 2560),) * 2, Image.LANCZOS)
        bgi.save(os.path.join(out, "bg.jpg"), quality=cfg.get("background_quality", 88), optimize=True, progressive=True)
        manifest["background"] = "bg.jpg"
    manifest["character"] = "body.png"          # 旧版本客户端 / 动效关闭时的静态立绘
    if cfg.get("vars"): manifest["vars"] = cfg["vars"]
    if cfg.get("css"): manifest["css"] = cfg["css"]
    manifest["scene"] = scene
    tl = cfg.get("timeline")
    if tl:
        out_tl = {}
        for key in ("art", "mark"):
            if not tl.get(key): continue
            src = P(cfg, tl[key]); name = f"timeline_{key}{os.path.splitext(src)[1].lower()}"
            if name.endswith(".svg"):
                low = open(src, encoding="utf-8").read().lower()
                bad = [b for b in SIMPLE_SVG_BANNED if b in low]
                if bad or "http" in low.replace("http://www.w3.org/2000/svg", "").replace("http://www.w3.org/1999/xlink", ""):
                    sys.exit(f"✗ {src} 含有客户端不允许的内容：{bad or '外链'}（SVG 必须是纯静态图形）")
            shutil.copy(src, os.path.join(out, name)); out_tl[key] = name
        for key in ("height", "railColor"):
            if key in tl: out_tl[key] = tl[key]
        manifest["timeline"] = out_tl
    if cfg.get("globalFx"): manifest["globalFx"] = cfg["globalFx"]
    json.dump(manifest, open(os.path.join(out, "skin.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    # 校验，和客户端 skins.rs 的限制一致
    total = 0
    for f in os.listdir(out):
        s = os.path.getsize(os.path.join(out, f)); total += s
        if s > MAX_ASSET: sys.exit(f"✗ {f} 超过 8 MiB")
    if total > MAX_TOTAL: sys.exit("✗ 皮肤包总大小超过 32 MiB")
    if os.path.getsize(os.path.join(out, "skin.json")) > 64 << 10: sys.exit("✗ skin.json 超过 64 KiB")
    if len(layers) > 16: sys.exit("✗ 表情层超过 16 个")
    missing = [e for e in DEFAULT_ON if e not in on]
    zpath = os.path.join(P(cfg, cfg["dist_dir"]), f"{sid}.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(os.listdir(out)): z.write(os.path.join(out, f), f"{sid}/{f}")
    print(f"\n✓ {zpath}  ({total / 1048576:.1f} MiB, 表情层 {sorted(names)}, 事件 {on})")
    if missing: print(f"  注意：这些事件没有绑定表情：{missing}")


if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in ("inspect", "build"):
        print(__doc__); sys.exit(1)
    c = load_cfg(sys.argv[2])
    (inspect if sys.argv[1] == "inspect" else build)(c)
