"""渲染冒烟测试 + 预览视频（用客户端真实的引擎代码 engine.js）。
python record.py <皮肤目录 package/<id>> <输出目录> [--quick]
输出：sheet.png（待机/点击/发送/说话/完成/出错 六格）、heads.png（头部特写）、preview.mp4（约 20 秒）、控制台错误。
依赖：pip install playwright imageio imageio-ffmpeg && python -m playwright install --with-deps chromium"""
import sys, os, shutil, http.server, threading, functools, io
from playwright.sync_api import sync_playwright
from PIL import Image

skin, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]); os.makedirs(out, exist_ok=True)
quick = "--quick" in sys.argv
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.join(out, "_srv"); shutil.rmtree(root, ignore_errors=True)
shutil.copytree(here, root, ignore=shutil.ignore_patterns("*.py")); shutil.copytree(skin, os.path.join(root, "skin"))
class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=root))
threading.Thread(target=srv.serve_forever, daemon=True).start()
W, H = 1120, 640
STAGE_NOTE = "stage 360x640 in page"
# 时间线（毫秒）：待机 → 点击人物 → 一次失败 → 发送 → 回复中（说一阵停一阵）→ 完成（完成特效最重，放最后）
PLAN = [(2600, "click"), (4800, "agent.error"), (7400, "message.send"), (8800, "agent.streaming"), (15200, "agent.done")]
SHOTS = [("idle", 1800), ("click", 3000), ("error", 5200), ("send", 7700), ("talk", 10000), ("done", 15700)]
END = 21000
with sync_playwright() as p:
    b = p.chromium.launch(args=["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
    pg = b.new_page(viewport={"width": W, "height": H}); errs = []
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None); pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(f"http://127.0.0.1:{srv.server_port}/index.html"); pg.wait_for_function("window.ready", timeout=30000)
    # 找一个落在人物脸附近的不透明点，用真实鼠标点击（走 hitTest 路径）
    face = pg.evaluate("""() => { const c = document.getElementById('c').getBoundingClientRect();
        for (let y = c.top + c.height * .15; y < c.bottom; y += 6) for (let x = c.left + c.width * .3; x < c.right - c.width * .3; x += 6)
          if (r.hitTest(x, y)) return [x, y + 40]; return null; }""")
    import time, imageio.v2 as iio, numpy as np
    writer = iio.get_writer(os.path.join(out, "preview.mp4"), fps=10, codec="libx264", quality=7, macro_block_size=8)
    shots, step, clicked, nframes = {}, 0, False, 0
    t0 = time.monotonic(); t = 0; last_frame_t = -100
    while t < END:
        while step < len(PLAN) and t >= PLAN[step][0]:
            ev = PLAN[step][1]
            if ev == "click":
                if face: pg.mouse.click(*face); clicked = True
            else: pg.evaluate(f"emit('{ev}')")
            step += 1
        if t > 1000 and t < 1100: pg.mouse.move(W * .9, H * .25)
        _s = time.monotonic(); img = Image.open(io.BytesIO(pg.screenshot(type="jpeg", quality=85))).convert("RGB")
        if time.monotonic() - _s > 1: print(f"  slow screenshot at {t/1000:.1f}s: {time.monotonic() - _s:.1f}s")
        # 按真实时间补帧，让视频节奏与实际一致（截图较慢时重复上一帧）
        while last_frame_t + 100 <= t:
            writer.append_data(np.asarray(img)); last_frame_t += 100; nframes += 1
        for name, at in SHOTS:
            if name not in shots and t >= at: shots[name] = img
        t = (time.monotonic() - t0) * 1000
    print(f"slowest gap handled; total {t/1000:.1f}s")
    writer.close()
    print("character hit point:", face, "clicked:", clicked, "video frames:", nframes)
    print("renderer fails:", pg.evaluate("fails"), "console errors:", errs); b.close()
cw = 640
sheet = Image.new("RGB", (cw * 3, 360 * 2))
for i, (name, im) in enumerate(shots.items()):
    sheet.paste(im.resize((cw, 360)), ((i % 3) * cw, (i // 3) * 360))
sheet.save(os.path.join(out, "sheet.png"))
heads = Image.new("RGB", (220 * len(shots), 240))
for i, im in enumerate(shots.values()):
    heads.paste(im.crop((70, 40, 290, 280)).resize((220, 240)), (i * 220, 0))
heads.save(os.path.join(out, "heads.png"))
shutil.rmtree(root); srv.shutdown(); print("→", out)
