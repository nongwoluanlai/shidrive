// bus.ts
var SKIN_EVENTS = ["message.send", "agent.streaming", "agent.done", "agent.error", "skin.enter", "character.click"];
var handlers = /* @__PURE__ */ new Set();
function onSkinEvent(handler) {
  handlers.add(handler);
  return () => handlers.delete(handler);
}
function emitSkinEvent(event) {
  for (const handler of handlers) {
    try {
      handler(event);
    } catch (error) {
      console.warn("[skin-fx]", error);
    }
  }
}
var isSkinEvent = (value) => SKIN_EVENTS.includes(value);

// scene.ts
var num = (v, min, max, def) => {
  const n = typeof v === "number" && Number.isFinite(v) ? v : def;
  return Math.min(max, Math.max(min, n));
};
var vec = (v, min, max, def) => Array.isArray(v) && v.length === 2 ? [num(v[0], min, max, def[0]), num(v[1], min, max, def[1])] : def;
var range = (v, min, max, def) => {
  const r = vec(v, min, max, def);
  return r[0] <= r[1] ? r : [r[1], r[0]];
};
var PARAM = /^[a-z][a-zA-Z0-9_]{0,31}$/;
var MAX_SIZE = 8192;
var DEFAULT_BURST = [900, 2200];
var DEFAULT_REST = [350, 1100];
function sanitizeFlap(param, raw) {
  if (typeof raw === "string") {
    const m = /^flap\((\d{2,4})\.\.(\d{2,4})\)$/.exec(raw);
    if (!m) return null;
    return { param, open: range([Number(m[1]), Number(m[2])], 40, 2e3, [100, 170]), burst: DEFAULT_BURST, rest: DEFAULT_REST };
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const r = raw;
  if (!("flap" in r)) return null;
  return {
    param,
    open: range(r.flap, 40, 2e3, [100, 170]),
    burst: r.burst === null ? null : range(r.burst, 200, 2e4, DEFAULT_BURST),
    rest: r.rest === null ? null : range(r.rest, 100, 2e4, DEFAULT_REST)
  };
}
function sanitizeScene(raw) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  if (typeof r.body?.src !== "string" || typeof r.mask !== "string") return null;
  const size = vec(r.body.size, 1, MAX_SIZE, [0, 0]);
  if (!size[0] || !size[1]) return null;
  const [W, H] = size;
  const layers = (Array.isArray(r.layers) ? r.layers : []).slice(0, 16).flatMap((l, i) => {
    if (typeof l?.src !== "string" || !Array.isArray(l.rect) || l.rect.length !== 4) return [];
    const rect = l.rect.map((v) => num(v, 0, MAX_SIZE, 0));
    if (rect[2] < 1 || rect[3] < 1) return [];
    const bind = typeof l.bind === "string" && PARAM.test(l.bind) ? l.bind : typeof l.id === "string" && PARAM.test(l.id) ? l.id : `layer${i}`;
    return [{ id: String(l.id ?? bind).slice(0, 32), src: l.src, rect, bind, slide: vec(l.slide, -200, 200, [0, 0]) }];
  });
  const idle = r.idle ?? {};
  const clips = {};
  for (const [name, c] of Object.entries(r.clips ?? {}).slice(0, 24)) {
    if (!PARAM.test(name) || !c || typeof c !== "object") continue;
    const clip = {
      dur: num(c.dur, 50, 3e4, 1500),
      keys: {},
      until: isSkinEvent(c.until) ? c.until : void 0,
      maxDur: num(c.maxDur, 500, 12e4, 3e4),
      cooldown: num(c.cooldown, 0, 6e4, 0)
    };
    for (const [param, keys] of Object.entries(c.keys ?? {}).slice(0, 16)) {
      if (!PARAM.test(param)) continue;
      const flap = sanitizeFlap(param, keys);
      if (flap) {
        clip.flap = flap;
        continue;
      }
      if (!Array.isArray(keys)) continue;
      const clean = keys.slice(0, 32).filter((k) => Array.isArray(k) && k.length === 2).map((k) => [num(k[0], 0, 3e4, 0), num(k[1], -1, 1, 0)]).sort((a, b) => a[0] - b[0]);
      if (clean.length) clip.keys[param] = clean;
    }
    clips[name] = clip;
  }
  const on = {};
  for (const [event, value] of Object.entries(r.on ?? {})) {
    const names = (Array.isArray(value) ? value : [value]).filter((n) => typeof n === "string" && !!clips[n]).slice(0, 8);
    if (isSkinEvent(event) && names.length) on[event] = names;
  }
  for (const name of on["agent.streaming"] ?? []) {
    const c = clips[name];
    if (c.flap && !c.until) c.until = "agent.done";
  }
  const actionClips = (Array.isArray(idle.actions?.clips) ? idle.actions.clips : []).filter((n) => typeof n === "string" && !!clips[n]).slice(0, 8);
  return {
    body: { src: r.body.src, size, grid: vec(r.body.grid, 4, 96, [40, 72]).map(Math.round) },
    mask: r.mask,
    pivot: { neck: vec(r.pivot?.neck, 0, MAX_SIZE, [W * 0.48, H * 0.24]), chest: vec(r.pivot?.chest, 0, MAX_SIZE, [W * 0.52, H * 0.35]) },
    layers,
    idle: {
      wind: num(idle.wind, 0, 2, 1),
      breath: num(idle.breath, 0, 2, 1),
      hairAmp: num(idle.hairAmp, 0, 90, 26),
      coatAmp: num(idle.coatAmp, 0, 60, 16),
      breathAmp: num(idle.breathAmp, 0, 0.04, 0.014),
      gust: num(idle.gust, 0, 1, 0.5),
      lag: num(idle.lag, 0, 3, 1),
      windDir: num(idle.windDir, -1, 1, 0.25),
      blinkEvery: range(idle.blink?.every, 0.5, 30, [2, 6]),
      blinkDouble: num(idle.blink?.double, 0, 1, 0.15),
      gazeMaxRot: num(idle.gaze?.maxRot, 0, 0.12, 0.045),
      actions: actionClips.length ? { every: range(idle.actions.every, 5, 600, [25, 60]), clips: actionClips } : null
    },
    clips,
    on
  };
}
var VS = `#version 300 es
in vec2 a;
uniform vec4 uRect; uniform vec2 uBody, uCanvas, uOff, uOrigin, uNeck, uChest;
uniform float uScale, uT, uWind, uBreath, uRot, uNod, uJolt, uHair, uCoat, uBreathAmp, uLag, uDir;
uniform sampler2D uMask;
out vec2 vUv;
void main() {
  vec2 p = uRect.xy + a * uRect.zw;
  vec4 m = textureLod(uMask, p / uBody, 0.);
  float t = uT;
  // hair: a wave travelling down each strand (tips lag behind roots) + slow drift + wind bias
  float hp = t * 1.6 - p.y * .011 - m.r * uLag * 1.8;
  float sway = sin(hp) * .55 + sin(hp * 2.3 + p.x * .02) * .22 + sin(t * .47 + p.x * .004 + 1.7) * .3;
  p.x += m.r * uWind * (sway + uDir) * uHair;
  p.y += m.r * uWind * (sin(hp * 1.3 + .9) * .3 - abs(uDir) * .15) * uHair;
  // cloth: broader, heavier flutter with a faster ripple on top
  float cp = t * 1.9 - p.y * .009 + p.x * .012 - m.g * uLag;
  p.x += m.g * uWind * (sin(cp) * .6 + sin(cp * 2.7 + 1.1) * .22 + uDir * .7) * uCoat;
  p.y += m.g * uWind * sin(cp * 1.4 + .4) * uCoat * .3;
  float b = sin(t * 6.2832 / 4.2) * .5 + .5;
  p += (p - uChest) * m.b * uBreath * uBreathAmp * b;
  p.y -= m.a * uBreath * b * 2.2;
  vec2 d = p - uNeck; float r = uRot * m.a;
  p = uNeck + vec2(d.x * cos(r) - d.y * sin(r), d.x * sin(r) + d.y * cos(r));
  p.y += m.a * (uNod * 7. - uJolt * 6.);
  p.x += m.a * uJolt * sin(t * 80.) * 2.;
  p += uOff;
  vec2 s = uOrigin + p * uScale;
  gl_Position = vec4(s.x / uCanvas.x * 2. - 1., 1. - s.y / uCanvas.y * 2., 0, 1);
  vUv = a;
}`;
var FS = `#version 300 es
precision mediump float;
in vec2 vUv; uniform sampler2D uTex; uniform float uAlpha; out vec4 o;
void main() { o = texture(uTex, vUv) * uAlpha; }`;
function sample(keys, t) {
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i][0]) {
      const [a0, v0] = keys[i - 1], [a1, v1] = keys[i];
      const k = (t - a0) / Math.max(1, a1 - a0), e = k < 0.5 ? 2 * k * k : 1 - (-2 * k + 2) ** 2 / 2;
      return v0 + (v1 - v0) * e;
    }
  }
  return keys[keys.length - 1][1];
}
var rand = ([a, b]) => a + Math.random() * (b - a);
var INTERACTIVE = "button,a,input,textarea,select,label,[role=button],[role=menuitem],[contenteditable=true],.cm-editor";
var SceneRenderer = class {
  constructor(canvas, spec, images, motion, onFail) {
    this.canvas = canvas;
    this.spec = spec;
    this.motion = motion;
    this.onFail = onFail;
    const gl = canvas.getContext("webgl2", { premultipliedAlpha: true, alpha: true, antialias: false });
    if (!gl) throw new Error("WebGL2 unavailable");
    this.gl = gl;
    this.initProgram();
    this.maskTex = this.texture(images.mask);
    this.body = { tex: this.texture(images.body), mesh: this.grid(spec.body.grid[0], spec.body.grid[1]), rect: [0, 0, spec.body.size[0], spec.body.size[1]], bind: "", slide: [0, 0] };
    this.layers = spec.layers.map((l, i) => ({ tex: this.texture(images.layers[i]), mesh: this.grid(10, 10), rect: l.rect, bind: l.bind, slide: l.slide }));
    for (const l of spec.layers) this.params[l.bind] = 0;
    this.buildHitMap(images.body);
    const now = performance.now();
    this.scheduleBlink(now);
    this.scheduleAction(now);
    canvas.addEventListener("webglcontextlost", this.onLost);
    addEventListener("pointermove", this.onPointer, { passive: true });
    addEventListener("pointerdown", this.onDown, { passive: true, capture: true });
    this.resize = new ResizeObserver(() => this.fit());
    this.resize.observe(canvas);
    this.fit();
    this.raf = requestAnimationFrame(this.loop);
  }
  gl;
  prog;
  u = {};
  body;
  layers = [];
  maskTex;
  params = {};
  running = [];
  lastStart = /* @__PURE__ */ new Map();
  blink = null;
  nextBlink = 0;
  nextAction = Infinity;
  gust = 1;
  gustTarget = 1;
  nextGust = 0;
  rot = 0;
  targetRot = 0;
  raf = 0;
  lastFrame = 0;
  lastTick = 0;
  dirty = true;
  disposed = false;
  cssW = 1;
  cssH = 1;
  scale = 1;
  originY = 0;
  hit = null;
  resize;
  onPointer = (e) => {
    const r = this.canvas.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / Math.max(400, innerWidth * 0.6);
    this.targetRot = Math.max(-1, Math.min(1, dx)) * this.spec.idle.gazeMaxRot;
  };
  onDown = (e) => {
    if (e.button !== 0 || e.target instanceof Element && e.target.closest(INTERACTIVE)) return;
    if (this.hitTest(e.clientX, e.clientY)) emitSkinEvent("character.click");
  };
  onLost = (e) => {
    e.preventDefault();
    this.fail("WebGL context lost");
  };
  /** Is the (client) point over an opaque pixel of the character? */
  hitTest(clientX, clientY) {
    if (!this.hit) return false;
    const r = this.canvas.getBoundingClientRect();
    const [W, H] = this.spec.body.size;
    const x = (clientX - r.left - 6) / this.scale, y = (clientY - r.top - this.originY) / this.scale;
    if (x < 0 || y < 0 || x >= W || y >= H) return false;
    const hx = Math.floor(x / W * this.hit.w), hy = Math.floor(y / H * this.hit.h);
    return this.hit.a[hy * this.hit.w + hx] > 96;
  }
  trigger(event) {
    const now = performance.now();
    const before = this.running.length;
    this.running = this.running.filter((r) => r.stopOn !== event);
    if (this.running.length !== before) this.dirty = true;
    const names = this.spec.on[event];
    if (!names?.length) return;
    this.start(names[Math.floor(Math.random() * names.length)], now);
    this.scheduleAction(now);
  }
  invalidate() {
    this.dirty = true;
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    this.resize.disconnect();
    removeEventListener("pointermove", this.onPointer);
    removeEventListener("pointerdown", this.onDown, { capture: true });
    this.canvas.removeEventListener("webglcontextlost", this.onLost);
    const gl = this.gl;
    for (const l of [this.body, ...this.layers]) gl.deleteTexture(l.tex);
    gl.deleteTexture(this.maskTex);
    gl.deleteProgram(this.prog);
    gl.getExtension("WEBGL_lose_context")?.loseContext();
  }
  start(name, now) {
    const clip = this.spec.clips[name];
    if (!clip) return;
    if (now - (this.lastStart.get(clip) ?? -Infinity) < clip.cooldown) return;
    this.lastStart.set(clip, now);
    this.running = this.running.filter((r) => r.clip !== clip);
    const until = clip.until ? now + clip.maxDur : now + clip.dur;
    this.running.push({ clip, t0: now, until, stopOn: clip.until, open: 0, nextToggle: now, speaking: true, phaseEnd: clip.flap?.burst ? now + rand(clip.flap.burst) : Infinity });
    this.dirty = true;
  }
  fail(reason) {
    if (this.disposed) return;
    this.dispose();
    this.onFail(reason);
  }
  buildHitMap(img) {
    try {
      const w = Math.max(1, Math.round(img.naturalWidth / 4)), h = Math.max(1, Math.round(img.naturalHeight / 4));
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      const ctx = c.getContext("2d", { willReadFrequently: true });
      if (!ctx) return;
      ctx.drawImage(img, 0, 0, w, h);
      const data = ctx.getImageData(0, 0, w, h).data;
      const a = new Uint8ClampedArray(w * h);
      for (let i = 0; i < a.length; i++) a[i] = data[i * 4 + 3];
      this.hit = { w, h, a };
    } catch {
      this.hit = null;
    }
  }
  initProgram() {
    const gl = this.gl;
    const shader = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? "shader error");
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, shader(gl.VERTEX_SHADER, VS));
    gl.attachShader(p, shader(gl.FRAGMENT_SHADER, FS));
    gl.bindAttribLocation(p, 0, "a");
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p) ?? "link error");
    this.prog = p;
    gl.useProgram(p);
    for (const n of ["uRect", "uBody", "uCanvas", "uOff", "uOrigin", "uNeck", "uChest", "uScale", "uT", "uWind", "uBreath", "uRot", "uNod", "uJolt", "uHair", "uCoat", "uBreathAmp", "uLag", "uDir", "uMask", "uTex", "uAlpha"]) {
      this.u[n] = gl.getUniformLocation(p, n);
    }
  }
  grid(cx, cy) {
    const gl = this.gl, v = [], idx = [];
    for (let y = 0; y <= cy; y++) for (let x = 0; x <= cx; x++) v.push(x / cx, y / cy);
    for (let y = 0; y < cy; y++) for (let x = 0; x < cx; x++) {
      const i = y * (cx + 1) + x, j = i + cx + 1;
      idx.push(i, i + 1, j, i + 1, j + 1, j);
    }
    const vao = gl.createVertexArray();
    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v), gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, gl.createBuffer());
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(idx), gl.STATIC_DRAW);
    gl.bindVertexArray(null);
    return { vao, count: idx.length };
  }
  texture(img) {
    const gl = this.gl, t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, img);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  fit() {
    const dpr = Math.min(devicePixelRatio || 1, 1.5);
    this.cssW = Math.max(1, this.canvas.clientWidth);
    this.cssH = Math.max(1, this.canvas.clientHeight);
    this.canvas.width = Math.round(this.cssW * dpr);
    this.canvas.height = Math.round(this.cssH * dpr);
    const [W, H] = this.spec.body.size;
    this.scale = Math.min(this.cssH * 0.98 / H, this.cssW * 0.95 / W);
    this.originY = this.cssH - H * this.scale;
    this.dirty = true;
  }
  scheduleBlink(now) {
    this.nextBlink = now + rand(this.spec.idle.blinkEvery) * 1e3;
  }
  scheduleAction(now) {
    const a = this.spec.idle.actions;
    this.nextAction = a ? now + rand(a.every) * 1e3 : Infinity;
  }
  /** Advance parameters; returns true while something is animating. */
  update(now, level) {
    let active = false;
    const P = this.params;
    for (const k of Object.keys(P)) P[k] = 0;
    P.nod = 0;
    P.jolt = 0;
    P.blinkHold = 0;
    this.running = this.running.filter((r) => now < r.until);
    const actions = this.spec.idle.actions;
    if (actions && now > this.nextAction) {
      if (!this.running.length && !document.hidden) this.start(actions.clips[Math.floor(Math.random() * actions.clips.length)], now);
      this.scheduleAction(now);
    }
    for (const r of this.running) {
      const t = now - r.t0;
      for (const [param, keys] of Object.entries(r.clip.keys)) P[param] = Math.max(P[param] ?? 0, sample(keys, r.stopOn ? Math.min(t, keys[keys.length - 1][0]) : t));
      const f = r.clip.flap;
      if (f) {
        if (f.burst && f.rest && now > r.phaseEnd) {
          r.speaking = !r.speaking;
          r.phaseEnd = now + rand(r.speaking ? f.burst : f.rest);
          if (!r.speaking) r.open = 0;
        }
        if (r.speaking && now > r.nextToggle) {
          r.open = r.open ? 0 : 1;
          r.nextToggle = now + rand(f.open);
        }
        P[f.param] = Math.max(P[f.param] ?? 0, r.open);
      }
      active = true;
    }
    if (!this.blink && now > this.nextBlink && !(P.blinkHold > 0.3)) this.blink = { t0: now, double: Math.random() < this.spec.idle.blinkDouble };
    if (this.blink) {
      const t = now - this.blink.t0, one = [[0, 0], [60, 1], [100, 1], [190, 0]];
      const end = this.blink.double ? 450 : 190;
      P.blink = Math.max(P.blink ?? 0, t < 190 ? sample(one, t) : this.blink.double && t > 260 && t < 450 ? sample(one, t - 260) : 0);
      if (t > end) {
        this.blink = null;
        this.scheduleBlink(now);
      }
      active = true;
    }
    const dr = this.targetRot - this.rot;
    if (Math.abs(dr) > 5e-4) {
      this.rot += dr * 0.12;
      active = true;
    }
    if (level === "full" && this.spec.idle.gust > 0) {
      if (now > this.nextGust) {
        const g = this.spec.idle.gust, strong = Math.random() < 0.3;
        this.gustTarget = strong ? 1 + g * (0.6 + Math.random() * 0.6) : 1 - g * 0.45 + Math.random() * g * 0.6;
        this.nextGust = now + (strong ? 1200 + Math.random() * 1200 : 2500 + Math.random() * 4500);
      }
      const dt = Math.min(100, now - this.lastTick);
      this.gust += (this.gustTarget - this.gust) * (1 - Math.exp(-dt / 700));
    }
    this.lastTick = now;
    return active;
  }
  loop = (now) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    if (document.hidden) return;
    const level = this.motion();
    const wind = level === "full" ? this.spec.idle.wind * this.gust : 0;
    const breath = level === "full" ? this.spec.idle.breath : 0;
    const active = this.update(now, level);
    const continuous = wind > 0 || breath > 0;
    if ((continuous || active || this.dirty) && now - this.lastFrame >= 1e3 / 30 - 1) {
      this.render(now, wind, breath);
      this.lastFrame = now;
      this.dirty = false;
    }
  };
  render(now, wind, breath) {
    const gl = this.gl, u = this.u, s = this.spec, P = this.params;
    if (gl.isContextLost()) return;
    const [W, H] = s.body.size;
    gl.viewport(0, 0, this.canvas.width, this.canvas.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.useProgram(this.prog);
    gl.uniform2f(u.uBody, W, H);
    gl.uniform2f(u.uCanvas, this.cssW, this.cssH);
    gl.uniform2f(u.uOrigin, 6, this.originY);
    gl.uniform2f(u.uNeck, ...s.pivot.neck);
    gl.uniform2f(u.uChest, ...s.pivot.chest);
    gl.uniform1f(u.uScale, this.scale);
    gl.uniform1f(u.uT, now / 1e3);
    gl.uniform1f(u.uWind, wind);
    gl.uniform1f(u.uBreath, breath);
    gl.uniform1f(u.uHair, s.idle.hairAmp);
    gl.uniform1f(u.uCoat, s.idle.coatAmp);
    gl.uniform1f(u.uBreathAmp, s.idle.breathAmp);
    gl.uniform1f(u.uLag, s.idle.lag);
    gl.uniform1f(u.uDir, s.idle.windDir * Math.min(1.4, this.gust));
    gl.uniform1f(u.uRot, this.rot + (wind ? Math.sin(now / 1900) * 6e-3 : 0));
    gl.uniform1f(u.uNod, P.nod ?? 0);
    gl.uniform1f(u.uJolt, P.jolt ?? 0);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.maskTex);
    gl.uniform1i(u.uMask, 0);
    gl.uniform1i(u.uTex, 1);
    const draw = (l, alpha, off) => {
      if (alpha < 0.01) return;
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, l.tex);
      gl.uniform4f(u.uRect, ...l.rect);
      gl.uniform2f(u.uOff, ...off);
      gl.uniform1f(u.uAlpha, Math.min(1, alpha));
      gl.bindVertexArray(l.mesh.vao);
      gl.drawElements(gl.TRIANGLES, l.mesh.count, gl.UNSIGNED_SHORT, 0);
    };
    draw(this.body, 1, [0, 0]);
    let top = "", topV = 0;
    const binds = new Set(this.layers.map((l) => l.bind));
    for (const r of this.running) {
      for (const param of [...Object.keys(r.clip.keys), ...r.clip.flap ? [r.clip.flap.param] : []]) {
        if (param !== "blink" && binds.has(param) && (P[param] ?? 0) > 0.01) {
          top = param;
          topV = P[param];
        }
      }
    }
    for (const l of this.layers) {
      let v = Math.max(0, P[l.bind] ?? 0);
      if (l.bind !== "blink" && l.bind !== top) v = 0;
      if (l.bind === "blink" && top && topV > 0.5) v = 0;
      draw(l, v, [l.slide[0] * (1 - v), l.slide[1] * (1 - v)]);
    }
    gl.bindVertexArray(null);
  }
};

// global-fx.ts
var FX_NAMES = ["shake", "flash", "slices", "rgbSplit", "hueShift", "vignette", "overlayText", "divergence", "scanlines", "noise", "tint", "ring", "particles"];
var LITE_SAFE = /* @__PURE__ */ new Set(["overlayText", "vignette", "divergence", "tint"]);
var BLENDS = ["normal", "multiply", "screen", "overlay", "color", "soft-light", "hue", "saturation"];
var MAX_PRESETS = 12;
var MAX_STEPS = 24;
var MAX_AT = 3e3;
var COOLDOWN_MS = 1200;
var num2 = (v, min, max, def) => {
  const n = typeof v === "number" && Number.isFinite(v) ? v : def;
  return Math.min(max, Math.max(min, n));
};
var pick = (list) => list[Math.floor(Math.random() * list.length)];
var hex = (v, def) => typeof v === "string" && /^#[\da-f]{3}([\da-f]{3})?$/i.test(v) ? v : def;
function sanitizeStep(raw) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  const fx = r.fx;
  if (!FX_NAMES.includes(fx)) return null;
  const at = num2(r.at, 0, MAX_AT, 0);
  switch (fx) {
    case "shake":
      return { at, fx, px: num2(r.px, 1, 20, 8), dur: num2(r.dur, 100, 1500, 400), steps: r.steps === true };
    case "flash":
      return { at, fx, color: hex(r.color, "#ffffff"), opacity: num2(r.opacity, 0.05, 0.6, 0.35), dur: num2(r.dur, 80, 800, 250) };
    case "slices":
      return { at, fx, n: Math.round(num2(r.n, 1, 14, 8)), dur: num2(r.dur, 200, 1500, 900), color: hex(r.color, "#ffb347") };
    case "rgbSplit":
      return { at, fx, px: num2(r.px, 1, 12, 6), dur: num2(r.dur, 100, 1500, 600) };
    case "hueShift":
      return { at, fx, deg: num2(r.deg, -180, 180, 40), dur: num2(r.dur, 100, 1500, 500) };
    case "vignette":
      return { at, fx, color: hex(r.color, "#000000"), opacity: num2(r.opacity, 0.1, 0.8, 0.5), dur: num2(r.dur, 200, 3e3, 900) };
    case "overlayText": {
      const text = typeof r.text === "string" ? r.text.replace(/[\u0000-\u001f]/g, "").slice(0, 24) : "";
      return { at, fx, style: r.style === "plain" ? "plain" : "nixie", text, roll: num2(r.roll, 0, 1500, 1e3), dur: num2(r.dur, 400, 3e3, 2400), color: hex(r.color, "#ffb347") };
    }
    case "divergence": {
      const values = (Array.isArray(r.values) ? r.values : []).filter((v) => typeof v === "string" && /^[0-9.]{1,12}$/.test(v)).slice(0, 16);
      return { at, fx, values, color: hex(r.color, "#ff9a3c"), roll: num2(r.roll, 0, 2500, 900), lock: num2(r.lock, 0, 400, 90), dur: num2(r.dur, 600, 4e3, 2600), y: num2(r.y, 0.05, 0.9, 0.16), size: num2(r.size, 20, 72, 40) };
    }
    case "scanlines":
      return { at, fx, color: hex(r.color, "#000000"), opacity: num2(r.opacity, 0.05, 0.6, 0.25), gap: num2(r.gap, 2, 8, 3), dur: num2(r.dur, 200, 3e3, 900) };
    case "noise":
      return { at, fx, opacity: num2(r.opacity, 0.03, 0.4, 0.12), dur: num2(r.dur, 150, 3e3, 700) };
    case "tint":
      return { at, fx, color: hex(r.color, "#ff9a3c"), opacity: num2(r.opacity, 0.05, 0.6, 0.2), blend: BLENDS.includes(r.blend) ? r.blend : "color", dur: num2(r.dur, 200, 3e3, 900) };
    case "ring":
      return { at, fx, color: hex(r.color, "#ffb347"), x: num2(r.x, 0, 1, 0.5), y: num2(r.y, 0, 1, 0.5), size: num2(r.size, 0.1, 2, 0.9), width: num2(r.width, 1, 12, 3), dur: num2(r.dur, 200, 2e3, 800) };
    case "particles": {
      const shape = ["dot", "spark", "digit"].includes(r.shape) ? r.shape : "dot";
      return { at, fx, color: hex(r.color, "#ffb347"), n: Math.round(num2(r.n, 1, 40, 18)), shape, dir: r.dir === "down" ? "down" : "up", dur: num2(r.dur, 400, 3e3, 1600) };
    }
  }
}
function sanitizeGlobalFx(raw) {
  if (!raw || typeof raw !== "object") return null;
  const r = raw;
  const presets = {};
  if (r.presets && typeof r.presets === "object") {
    for (const [name, steps] of Object.entries(r.presets).slice(0, MAX_PRESETS)) {
      if (!/^[a-z][a-z0-9_-]{0,31}$/.test(name) || !Array.isArray(steps)) continue;
      const clean = steps.slice(0, MAX_STEPS).map(sanitizeStep).filter((s) => !!s);
      if (clean.length) presets[name] = clean;
    }
  }
  const names = (v) => (Array.isArray(v) ? v : [v]).filter((n) => typeof n === "string" && !!presets[n]).slice(0, 8);
  const on = {};
  if (r.on && typeof r.on === "object") {
    for (const [event, value] of Object.entries(r.on)) {
      const list = names(value);
      if (isSkinEvent(event) && list.length) on[event] = list;
    }
  }
  const amb = r.ambient;
  const ambPlay = amb ? names(amb.play) : [];
  const every = Array.isArray(amb?.every) ? [num2(amb.every[0], 20, 3600, 90), num2(amb.every[1], 20, 3600, 240)] : [90, 240];
  const ambient = ambPlay.length ? { every: [Math.min(...every), Math.max(...every)], play: ambPlay } : null;
  return Object.keys(on).length || ambient ? { presets, on, ambient } : null;
}
var GlobalFx = class {
  constructor(config, motion) {
    this.config = config;
    this.motion = motion;
    this.layer = document.createElement("div");
    this.layer.className = "skin-gfx-layer";
    this.layer.setAttribute("aria-hidden", "true");
    Object.assign(this.layer.style, { position: "fixed", inset: "0", zIndex: "350", pointerEvents: "none", overflow: "hidden" });
    document.body.appendChild(this.layer);
    this.scheduleAmbient();
  }
  layer;
  timers = /* @__PURE__ */ new Set();
  intervals = /* @__PURE__ */ new Set();
  anims = /* @__PURE__ */ new Set();
  lastPlayed = /* @__PURE__ */ new Map();
  flashes = [];
  handle(event) {
    const list = this.config.on[event];
    if (list?.length) this.play(pick(list));
  }
  ambientTimer = 0;
  scheduleAmbient() {
    const a = this.config.ambient;
    if (!a) return;
    const [lo, hi] = a.every;
    this.ambientTimer = window.setTimeout(() => {
      if (document.hasFocus() && !document.hidden) this.play(pick(a.play));
      this.scheduleAmbient();
    }, (lo + Math.random() * (hi - lo)) * 1e3);
  }
  play(name) {
    const steps = this.config.presets[name];
    const level = this.motion();
    if (!steps || level === "off" || document.hidden) return;
    const now = performance.now();
    if (now - (this.lastPlayed.get(name) ?? -Infinity) < COOLDOWN_MS) return;
    this.lastPlayed.set(name, now);
    for (const step of steps) {
      if (level === "lite" && !LITE_SAFE.has(step.fx)) continue;
      const id = window.setTimeout(() => {
        this.timers.delete(id);
        this.run(step);
      }, step.at);
      this.timers.add(id);
    }
  }
  dispose() {
    clearTimeout(this.ambientTimer);
    for (const id of this.timers) clearTimeout(id);
    for (const id of this.intervals) clearInterval(id);
    for (const a of this.anims) a.cancel();
    this.timers.clear();
    this.intervals.clear();
    this.anims.clear();
    this.layer.remove();
  }
  track(anim, cleanup) {
    this.anims.add(anim);
    const done = () => {
      this.anims.delete(anim);
      cleanup?.();
    };
    anim.onfinish = done;
    anim.oncancel = done;
  }
  root() {
    return document.querySelector(".root");
  }
  overlay(css) {
    const el = document.createElement("div");
    Object.assign(el.style, { position: "absolute", inset: "0", pointerEvents: "none" }, css);
    this.layer.appendChild(el);
    return el;
  }
  run(s) {
    const R = (a, b) => a + Math.random() * (b - a);
    const dur = Number(s.dur);
    switch (s.fx) {
      case "shake": {
        const root = this.root();
        if (!root) return;
        const p = Number(s.px);
        const frames = Array.from({ length: 10 }, (_, i) => ({ transform: `translate(${R(-p, p) * (1 - i / 10)}px, ${R(-p, p) * (1 - i / 10)}px)` }));
        frames.push({ transform: "none" });
        this.track(root.animate(frames, { duration: dur, easing: s.steps ? "steps(1)" : "linear" }));
        break;
      }
      case "flash": {
        const now = performance.now();
        this.flashes = this.flashes.filter((t) => now - t < 1e3);
        if (this.flashes.length >= 3) return;
        this.flashes.push(now);
        const el = this.overlay({ background: String(s.color) });
        this.track(el.animate([{ opacity: Number(s.opacity) }, { opacity: 0 }], { duration: dur, fill: "forwards" }), () => el.remove());
        break;
      }
      case "slices": {
        for (let i = 0; i < Number(s.n); i++) {
          const el = this.overlay({ inset: "auto", left: "0", right: "0", top: `${R(0, 100)}%`, height: `${R(8, 50)}px`, background: `${s.color}22`, borderTop: `1px solid ${s.color}66`, opacity: "0" });
          const frames = Array.from({ length: 8 }, () => ({ opacity: Math.random() > 0.4 ? 1 : 0, transform: `translateX(${R(-60, 60)}px)`, backdropFilter: `hue-rotate(${R(0, 180)}deg) invert(${Math.random() > 0.7 ? 1 : 0})` }));
          frames.push({ opacity: 0 });
          this.track(el.animate(frames, { duration: dur, easing: "steps(1)", fill: "forwards" }), () => el.remove());
        }
        break;
      }
      case "rgbSplit": {
        const root = this.root();
        if (!root) return;
        const p = Number(s.px);
        const frames = Array.from({ length: 10 }, () => ({ filter: `drop-shadow(${R(-p, p)}px 0 0 #f0f8) drop-shadow(${R(-p, p)}px 0 0 #0ff8)` }));
        frames.push({ filter: "none" });
        this.track(root.animate(frames, { duration: dur, easing: "steps(1)" }));
        break;
      }
      case "hueShift": {
        const root = this.root();
        if (!root) return;
        this.track(root.animate([{ filter: "none" }, { filter: `hue-rotate(${s.deg}deg)` }, { filter: "none" }], { duration: dur }));
        break;
      }
      case "vignette": {
        const el = this.overlay({ background: `radial-gradient(ellipse at center, transparent 45%, ${s.color} 100%)`, opacity: "0" });
        this.track(el.animate([{ opacity: 0 }, { opacity: Number(s.opacity), offset: 0.3 }, { opacity: 0 }], { duration: dur, fill: "forwards" }), () => el.remove());
        break;
      }
      case "overlayText": {
        const nixie = s.style === "nixie";
        const color = String(s.color);
        const el = this.overlay({
          inset: "auto",
          left: "50%",
          top: "18%",
          transform: "translateX(-50%)",
          padding: "4px 16px",
          borderRadius: "6px",
          font: nixie ? "700 44px var(--mono, monospace)" : "700 28px var(--sans, sans-serif)",
          letterSpacing: nixie ? "6px" : "1px",
          color,
          textShadow: `0 0 6px ${color}, 0 0 18px ${color}, 0 0 40px ${color}`,
          background: nixie ? "#000a" : "transparent",
          border: nixie ? `1px solid ${color}66` : "none"
        });
        const final = String(s.text || "") || (Math.random() * 0.5 + 0.9).toFixed(6);
        const roll = Number(s.roll);
        const started = performance.now();
        el.textContent = final;
        if (roll > 0) {
          const id = window.setInterval(() => {
            if (performance.now() - started >= roll) {
              el.textContent = final;
              clearInterval(id);
              this.intervals.delete(id);
              return;
            }
            el.textContent = nixie ? (Math.random() * 2).toFixed(6) : final.split("").sort(() => Math.random() - 0.5).join("");
          }, 60);
          this.intervals.add(id);
        }
        this.track(el.animate([{ opacity: 1 }, { opacity: 1, offset: 0.75 }, { opacity: 0 }], { duration: dur, fill: "forwards" }), () => el.remove());
        break;
      }
      case "divergence": {
        const color = String(s.color), size = Number(s.size);
        const values = s.values;
        const final = values.length ? pick(values) : (Math.random() < 0.5 ? "0." : "1.") + String(Math.floor(Math.random() * 1e6)).padStart(6, "0");
        const box = this.overlay({ inset: "auto", left: "50%", top: `${Number(s.y) * 100}%`, transform: "translateX(-50%)", display: "flex", gap: `${size * 0.12}px`, padding: `${size * 0.18}px ${size * 0.3}px`, background: "#050302d9", border: `1px solid ${color}55`, borderRadius: "6px", boxShadow: `0 0 24px ${color}33, inset 0 0 18px #000` });
        const tubes = final.split("").map((ch) => {
          const t = document.createElement("span");
          Object.assign(t.style, {
            display: "inline-block",
            width: ch === "." ? `${size * 0.28}px` : `${size * 0.62}px`,
            height: `${size * 1.25}px`,
            lineHeight: `${size * 1.25}px`,
            textAlign: "center",
            font: `400 ${size}px var(--mono, monospace)`,
            color,
            textShadow: `0 0 3px ${color}, 0 0 10px ${color}aa`,
            background: ch === "." ? "transparent" : "linear-gradient(#1a0f08, #0b0604)",
            borderRadius: `${size * 0.3}px ${size * 0.3}px ${size * 0.08}px ${size * 0.08}px`,
            boxShadow: ch === "." ? "none" : `inset 0 0 ${size * 0.25}px #000, 0 0 ${size * 0.3}px ${color}22`
          });
          t.textContent = ch;
          box.appendChild(t);
          return t;
        });
        const roll = Number(s.roll), lock = Number(s.lock), started = performance.now();
        const id = window.setInterval(() => {
          const el = performance.now() - started;
          let busy = false;
          tubes.forEach((t, i) => {
            if (final[i] === ".") return;
            if (el < roll + i * lock) {
              t.textContent = String(Math.floor(Math.random() * 10));
              busy = true;
            } else t.textContent = final[i];
          });
          if (!busy) {
            clearInterval(id);
            this.intervals.delete(id);
          }
        }, 55);
        this.intervals.add(id);
        this.track(box.animate([{ opacity: 0 }, { opacity: 1, offset: 0.06 }, { opacity: 1, offset: 0.8 }, { opacity: 0 }], { duration: dur, fill: "forwards" }), () => box.remove());
        break;
      }
      case "scanlines": {
        const gap = Number(s.gap);
        const el = this.overlay({ inset: "auto", left: "0", right: "0", top: `${-gap * 20}px`, height: `calc(100% + ${gap * 40}px)`, background: `repeating-linear-gradient(0deg, ${s.color} 0 1px, transparent 1px ${gap}px)`, opacity: "0", willChange: "transform, opacity" });
        this.track(el.animate([{ opacity: 0, transform: "translateY(0)" }, { opacity: Number(s.opacity), offset: 0.2 }, { opacity: 0, transform: `translateY(${gap * 20}px)` }], { duration: dur, fill: "forwards" }), () => el.remove());
        break;
      }
      case "noise": {
        const el = this.overlay({ backgroundImage: `url(${noiseTile()})`, opacity: "0" });
        const frames = Array.from({ length: 8 }, (_, i) => ({ opacity: Number(s.opacity) * (i < 7 ? 1 : 0), backgroundPosition: `${Math.floor(R(0, 128))}px ${Math.floor(R(0, 128))}px` }));
        this.track(el.animate(frames, { duration: dur, easing: "steps(1)", fill: "forwards" }), () => el.remove());
        break;
      }
      case "tint": {
        const el = this.overlay({ background: String(s.color), mixBlendMode: String(s.blend), opacity: "0" });
        this.track(el.animate([{ opacity: 0 }, { opacity: Number(s.opacity), offset: 0.25 }, { opacity: Number(s.opacity), offset: 0.6 }, { opacity: 0 }], { duration: dur, fill: "forwards" }), () => el.remove());
        break;
      }
      case "ring": {
        const d = Math.max(innerWidth, innerHeight) * Number(s.size);
        const el = this.overlay({ inset: "auto", left: `${Number(s.x) * 100}%`, top: `${Number(s.y) * 100}%`, width: `${d}px`, height: `${d}px`, marginLeft: `${-d / 2}px`, marginTop: `${-d / 2}px`, borderRadius: "50%", border: `${s.width}px solid ${s.color}`, boxShadow: `0 0 8px ${s.color}`, willChange: "transform, opacity" });
        this.track(el.animate([{ transform: "scale(0.05)", opacity: 0.9 }, { transform: "scale(1)", opacity: 0 }], { duration: dur, easing: "cubic-bezier(.2,.7,.3,1)", fill: "forwards" }), () => el.remove());
        break;
      }
      case "particles": {
        const n = Number(s.n), color = String(s.color), up = s.dir !== "down";
        for (let i = 0; i < n; i++) {
          const size = s.shape === "digit" ? R(12, 20) : R(2, 5);
          const el = this.overlay({
            inset: "auto",
            left: `${R(0, 100)}%`,
            top: up ? "100%" : "-4%",
            width: s.shape === "digit" ? "auto" : `${size}px`,
            height: s.shape === "spark" ? `${size * 4}px` : s.shape === "digit" ? "auto" : `${size}px`,
            borderRadius: s.shape === "dot" ? "50%" : "2px",
            background: s.shape === "digit" ? "transparent" : color,
            color,
            font: `${size}px var(--mono, monospace)`,
            boxShadow: s.shape === "digit" ? "none" : `0 0 6px ${color}`,
            textShadow: s.shape === "digit" ? `0 0 4px ${color}` : "none",
            willChange: "transform, opacity"
          });
          if (s.shape === "digit") el.textContent = String(Math.floor(Math.random() * 10));
          const dy = (up ? -1 : 1) * innerHeight * R(0.35, 1.05), dx = R(-40, 40), d = dur * R(0.6, 1);
          this.track(el.animate([{ transform: "translate(0,0)", opacity: 0 }, { opacity: 1, offset: 0.15 }, { transform: `translate(${dx}px, ${dy}px)`, opacity: 0 }], { duration: d, delay: R(0, dur * 0.35), easing: "ease-out", fill: "both" }), () => el.remove());
        }
        break;
      }
    }
  }
};
var noiseUrl = "";
function noiseTile() {
  if (noiseUrl) return noiseUrl;
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const ctx = c.getContext("2d");
  if (!ctx) return "";
  const img = ctx.createImageData(128, 128);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = Math.random() * 255;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return noiseUrl = c.toDataURL();
}
export {
  GlobalFx,
  SceneRenderer,
  emitSkinEvent,
  onSkinEvent,
  sanitizeGlobalFx,
  sanitizeScene
};
