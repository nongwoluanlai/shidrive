#!/usr/bin/env bash
# 用客户端真实的 Rust 导入代码校验皮肤 zip（和 ShiDrive 导入时的规则完全一致）
# 用法：verify_import.sh <shidrive 仓库路径> <皮肤.zip> <皮肤id>
set -euo pipefail
REPO=$(realpath "$1"); ZIP=$(realpath "$2"); ID="$3"; T=${TMPDIR:-/tmp}/skin-verify
export PATH=$PATH:$HOME/.cargo/bin
command -v cargo >/dev/null || { curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal >/dev/null; }
rm -rf "$T"; mkdir -p "$T/src"
cat > "$T/Cargo.toml" <<C
[package]
name = "skin_verify"
version = "0.1.0"
edition = "2021"
[dependencies]
serde_json = "1"
uuid = { version = "1", features = ["v4"] }
zip = { version = "2", default-features = false, features = ["deflate"] }
C
echo "pub mod skins;" > "$T/src/lib.rs"
cp "$REPO/app/src-tauri/src/skins.rs" "$T/src/skins.rs"
cat >> "$T/src/skins.rs" <<R
#[cfg(test)]
mod package_under_test {
    #[test]
    fn imports_and_reads_assets() {
        let root = std::env::temp_dir().join(format!("skin-verify-{}", std::process::id()));
        std::fs::create_dir_all(&root).unwrap();
        let m = super::import(&root, std::path::Path::new("$ZIP")).expect("import failed");
        assert_eq!(m["id"], "$ID");
        let mut files: Vec<String> = ["background", "character"].iter().filter_map(|k| m[*k].as_str().map(String::from)).collect();
        let s = &m["scene"];
        files.extend([s["body"]["src"].as_str(), s["mask"].as_str()].into_iter().flatten().map(String::from));
        files.extend(["art", "mark"].iter().filter_map(|k| m["timeline"][*k].as_str().map(String::from)));
        if let Some(l) = s["layers"].as_array() { files.extend(l.iter().filter_map(|x| x["src"].as_str().map(String::from))); }
        for f in &files { super::asset_bytes(&root, "$ID", f).unwrap_or_else(|e| panic!("{f}: {e}")); }
        println!("OK: {} assets readable", files.len());
    }
}
R
cd "$T" && cargo test -q package_under_test -- --nocapture 2>&1 | grep -E "OK:|panicked|error|test result"
